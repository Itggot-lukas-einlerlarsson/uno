#include <iostream>
#include <iomanip>
#include <string>

int main(int argc, char const *argv[]) {
  std::string function = "REVERSE";
  std::string color = "GREEN";
  int number = -1;
  std::cout << "previously:\n" << "Number: " << number << "\tColor:" << color << "\tFunction: " << function <<'\n';

  std::cout << '\n';

  std::cout << "better format:" << '\n';
  std::cout << std::setw(15) << '\n';
  std::cout << "_________________________" <<'\t' << "_________________________" << '\n';
  std::cout << "|" << "\t" << "\t" << "\t" << "|" <<'\t' << "|" << "\t" << "\t" << "\t" << "|" << '\n'
            << "|" << "\t " << color << "\t\t" << "|" <<'\t' << "|" << "\t " << color << "\t\t" << "|" << '\n'
            << "|" << "\t" << function << "\t\t" << "|" <<'\t' <<  "|" << "\t" << function << "\t\t" << "|" << '\n'
            << "|" << "\t  " << number << "\t\t" << "|" <<'\t' << "|" << "\t  " << number << "\t\t" << "|" << '\n';
  std::cout << "|_______________________|" <<'\t' << "|_______________________|" ;
  std::cout << '\n';



  return 0;
}
